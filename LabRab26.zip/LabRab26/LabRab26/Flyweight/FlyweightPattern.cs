﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace LabRab26.FlyweightPattern
{
    public abstract class Nature //Абстрактный класс в котором содержаться наши природные сущности
    {
        public BitmapImage source { get; set; } //Свойство, которое хранит ссылку на картинку
    }

    public class Grass : Nature //Трава
    {
        public Grass()
        {
            source = new BitmapImage(new Uri("img/grass.jpg", UriKind.Relative));
        }
    }

    public class Ground : Nature //Земля
    {
        public Ground()
        {
            source = new BitmapImage(new Uri("img/ground.jpg", UriKind.Relative));
        }
    }

    public class Water : Nature //Вода
    {
        public Water()
        {
            source = new BitmapImage(new Uri("img/water.jpg", UriKind.Relative));
        }
    }

    public class NatureFactory //Фабрика, которая создаёт объекты Image и добавляет в словарь
    {
        public Dictionary<string, Image> nature = new Dictionary<string, Image>();
        public List<Nature> items = new List<Nature>();

        public NatureFactory()
        {
            if (items.Count < 1) //Заполнение списка items объектами всех сущностей
            {
                items = new List<Nature>
                {
                    new Grass(),
                    new Ground(),
                    new Water()
                };
            }

            nature = new Dictionary<string, Image>(); //Очищение словаря от прошлых записей

            for(int x = 0; x < 7; x++) //Цикл заполнения словаря объектами Image
            {
                for (int j = 0; j < 8; j++)
                {
                    nature.Add($"nature {x}{j}", new Image() { Name=$"Image{x}x{j}"});
                }
            }
        }

        public BitmapImage GetSource(int index)
        {
            return items[index].source;
        }
    }
}
