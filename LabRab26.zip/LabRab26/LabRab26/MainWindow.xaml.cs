﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using LabRab26.FlyweightPattern;

namespace LabRab26
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window //Клиентский код
    {
        NatureFactory natureFactory = new NatureFactory();

        public MainWindow()
        {
            InitializeComponent();

            for (int x = 0; x < 7; x++)
            {
                for (int j = 0; j < 8; j++)
                {
                    gridPictures.Children.Add(natureFactory.nature[$"nature {x}{j}"]);
                    Grid.SetColumn(natureFactory.nature[$"nature {x}{j}"], j);
                    Grid.SetRow(natureFactory.nature[$"nature {x}{j}"], x);
                }
            }
        }

        private void ShowInfo(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Строка: {(sender as Image).Name.Split("Image")[1].Split("x")[0]}, " + $"Колонка: {(sender as Image).Name.Split("Image")[1].Split("x")[1]}");
        }

        private void Spawn(object sender, RoutedEventArgs e)
        {
            bool flag = false;

            for (int x = 0; x < 7; x++)
            {
                if (flag == false)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (natureFactory.nature[$"nature {x}{j}"].Source == null)
                        {
                            switch ((sender as Button).Content)
                            {
                                case "Земля":
                                    natureFactory.nature[$"nature {x}{j}"].Source = new BitmapImage(new Uri(natureFactory.GetSource(0).ToString(), UriKind.Relative));
                                    break;
                                case "Трава":
                                    natureFactory.nature[$"nature {x}{j}"].Source = new BitmapImage(new Uri(natureFactory.GetSource(2).ToString(), UriKind.Relative));
                                    break;
                                case "Вода":
                                    natureFactory.nature[$"nature {x}{j}"].Source = new BitmapImage(new Uri(natureFactory.GetSource(1).ToString(), UriKind.Relative));
                                    break;
                            }

                            natureFactory.nature[$"nature {x}{j}"].MouseLeftButtonDown += ShowInfo;
                            flag = true;
                            break;
                        }
                    }
                }
            }
        }
    }
}
